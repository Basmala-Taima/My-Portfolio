# Required Laravel 12 integration notes

## 1) Middleware alias
Open `bootstrap/app.php`. Add this import at the top if missing:

```php
use App\Http\Middleware\AdminSession;
use Illuminate\Foundation\Configuration\Middleware;
```

Inside the existing `->withMiddleware(function (Middleware $middleware): void { ... })` callback, add:

```php
$middleware->alias([
    'admin.session' => AdminSession::class,
]);
```

Do not replace the rest of the Laravel bootstrap configuration.

## 2) Storage symlink
Run:

```bash
php artisan storage:link
```

## 3) Environment
Set a strong admin password in `.env`:

```env
ADMIN_EMAIL=your-email@example.com
ADMIN_PASSWORD=replace-this-with-a-long-unique-password
```

Then run:

```bash
php artisan migrate --seed
```

## 4) Routes
The supplied `routes/web.php` is intended to replace the default web routes file. The admin login is custom session-based; the `admin.session` alias protects admin pages. Change the seeded admin credentials immediately.
