# Basmala Taima Portfolio — Laravel 12 starter

This is a starter code overlay for a fresh Laravel 12 application (PHP 8.2+). It is not a complete Laravel installation and does not include `vendor/` or framework files.

## Setup
1. Create a Laravel 12 project: `composer create-project laravel/laravel basmala-portfolio "^12.0"`
2. Copy this folder's contents into the Laravel project, merging folders.
3. Configure MySQL in `.env` and create the database.
4. Run `php artisan key:generate` (if needed), then `php artisan migrate --seed`.
5. Run `npm install && npm run build` for Vite/Tailwind if using the standard Laravel 12 starter. The provided pages use a standalone stylesheet at `public/css/portfolio.css`, so no Tailwind build is required for this starter.
6. Run `php artisan serve`.

## Admin
A seeded admin is created by `AdminSeeder`:
- Email: `admin@example.com`
- Password: `ChangeMe123!`

Change these credentials immediately in a real deployment. The seeder reads `ADMIN_EMAIL` and `ADMIN_PASSWORD` from `.env` if set.

## Notes
- Public pages: `/`, `/about`, `/skills`, `/projects`, `/projects/{slug}`, `/certificates`, `/contact`.
- Admin pages: `/admin/login`, `/admin/dashboard`, `/admin/projects`, `/admin/skills`, `/admin/certificates`, `/admin/messages`.
- Admin CRUD in this starter covers projects, skills, and certificates; messages can be read and marked as read.
- Add CSRF protection, HTTPS, backups, and production-safe environment values before deployment.
