<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Skill;
use Illuminate\Http\Request;

class SkillController extends Controller
{
    public function index() { $skills = Skill::orderBy('category')->orderBy('sort_order')->paginate(20); return view('admin.skills.index', compact('skills')); }
    public function create() { return view('admin.skills.form', ['skill' => new Skill()]); }
    public function store(Request $request) { Skill::create($request->validate(['name'=>'required|string|max:80','category'=>'required|string|max:80','sort_order'=>'nullable|integer|min:0'])); return redirect()->route('admin.skills.index')->with('success','Skill created.'); }
    public function edit(Skill $skill) { return view('admin.skills.form', compact('skill')); }
    public function update(Request $request, Skill $skill) { $skill->update($request->validate(['name'=>'required|string|max:80','category'=>'required|string|max:80','sort_order'=>'nullable|integer|min:0'])); return redirect()->route('admin.skills.index')->with('success','Skill updated.'); }
    public function destroy(Skill $skill) { $skill->delete(); return back()->with('success','Skill deleted.'); }
}
