<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration { public function up(): void { Schema::create('messages', function (Blueprint $table) { $table->id(); $table->string('name'); $table->string('email'); $table->string('subject')->nullable(); $table->longText('message'); $table->boolean('is_read')->default(false); $table->timestamps(); }); } public function down(): void { Schema::dropIfExists('messages'); } };
